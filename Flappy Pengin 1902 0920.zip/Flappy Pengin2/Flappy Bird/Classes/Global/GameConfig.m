//
//  GameConfig.m
//  Created by Sentio on 27/1/2014.
//  Copyright 2014 Sentio Ltd. All rights reserved.
//

#import "GameConfig.h"
BOOL g_bMusicMute = NO;
BOOL g_bIsTimeMode = NO;
BOOL g_bSoundMute = YES;
int g_nDifficulty = D_EASY;
int g_nCurrentLevel = 0;

int g_nTotalScore = 0;

CCAnimation *g_frmBird;
CCAnimation *g_frmObstacle;
